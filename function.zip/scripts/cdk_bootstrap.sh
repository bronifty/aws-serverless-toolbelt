#!/bin/bash

pnpx cdk bootstrap aws://851725517932/us-east-1

