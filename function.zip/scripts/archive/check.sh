which go
which nats
which nats-server
which aws
which terraform
which docker
which git-lfs
which fnm
which nex
# cat /root/.bashrc

