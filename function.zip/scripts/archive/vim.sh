#!/bin/bash
sudo vim ~/.bashrc
