cat ~/.ssh/id_rsa.pub | xclip -selection clipboard

