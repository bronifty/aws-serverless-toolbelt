#!/bin/bash

pnpm unit