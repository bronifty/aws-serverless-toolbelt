#!/bin/bash

aws lambda list-functions