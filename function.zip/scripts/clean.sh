#!/bin/bash
# Clean previous installs
rm -rf node_modules 
rm -rf *.zip
rm -rf dist