#!/bin/bash

# Login to AWS SSO
aws sso login 