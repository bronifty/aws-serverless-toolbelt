#!/bin/bash

scp root@desktop:/Users/bronifty/Pictures/wing-website.png /path/to/local/directory
